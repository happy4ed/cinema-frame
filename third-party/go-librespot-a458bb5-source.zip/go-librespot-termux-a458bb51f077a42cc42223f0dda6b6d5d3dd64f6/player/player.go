package player

import (
	"context"
	"errors"
	"fmt"
	"io"
	"math"
	"net/http"
	"net/url"
	"sync/atomic"
	"time"

	librespot "github.com/devgianlu/go-librespot"
	"github.com/devgianlu/go-librespot/audio"
	"github.com/devgianlu/go-librespot/cache"
	"github.com/devgianlu/go-librespot/flac"
	"github.com/devgianlu/go-librespot/mp3"
	"github.com/devgianlu/go-librespot/output"
	"github.com/devgianlu/go-librespot/playplay"
	downloadpb "github.com/devgianlu/go-librespot/proto/spotify/download"
	extmetadatapb "github.com/devgianlu/go-librespot/proto/spotify/extendedmetadata"
	audiofilespb "github.com/devgianlu/go-librespot/proto/spotify/extendedmetadata/audiofiles"
	metadatapb "github.com/devgianlu/go-librespot/proto/spotify/metadata"
	streamingpb "github.com/devgianlu/go-librespot/proto/spotify/streaming"
	"github.com/devgianlu/go-librespot/spclient"
	"github.com/devgianlu/go-librespot/vorbis"
	"golang.org/x/exp/rand"
)

const (
	SampleRate = 44100
	Channels   = 2
)

const MaxStateVolume = 65535

const CdnUrlQuarantineDuration = 15 * time.Minute

var ErrPlayerClosed = errors.New("player is closed")

func ptr[T any](v T) *T {
	return &v
}

type Player struct {
	log librespot.Logger

	crossfadeSamples          int
	flacEnabled               bool
	normalisationEnabled      bool
	normalisationUseAlbumGain bool
	normalisationPregain      float32
	countryCode               func() string

	sp       *spclient.Spclient
	audioKey *audio.KeyProvider
	events   EventManager

	cache *cache.Cache

	cdnQuarantine map[string]time.Time

	newOutput func(source librespot.Float32Reader, volume float32, device string) (output.Output, error)

	// defaultAudioDevice is the output device to open initially. manageLoop
	// tracks the current device from here and it can be changed at runtime via
	// ReopenOutput.
	defaultAudioDevice string

	cmd    chan playerCmd
	ev     chan Event
	closed chan struct{}

	volumeSteps uint32

	startedPlaying time.Time

	// optimisticPlaybackReplies controls when manageLoop replies to a
	// Play/Pause/Seek/Set command relative to the output actually confirming
	// the change - see Options.OptimisticPlaybackReplies.
	optimisticPlaybackReplies bool

	// streamGen counts the primary streams set, so that events can say which
	// one they came from. Written only by manageLoop, read from anywhere.
	streamGen atomic.Uint64
}

type playerCmdType int

const (
	playerCmdSet playerCmdType = iota
	playerCmdPlay
	playerCmdPause
	playerCmdStop
	playerCmdSeek
	playerCmdPosition
	playerCmdVolume
	playerCmdReopenOutput
	playerCmdClose
)

type playerCmd struct {
	typ  playerCmdType
	data any
	resp chan any
}

type playerCmdDataSet struct {
	source  librespot.AudioSource
	primary bool
	paused  bool
	drop    bool
}

type Options struct {
	Spclient *spclient.Spclient
	AudioKey *audio.KeyProvider
	Events   EventManager

	Log librespot.Logger

	// Cache, when non-nil, is used to store and retrieve encrypted audio files
	// on disk, avoiding a CDN download when a track is played again.
	Cache *cache.Cache

	// FlacEnabled specifies if FLAC files should be preferred when available.
	// When setting this to true, it is assumed that the PlayPlay plugin is provided.
	FlacEnabled bool

	// NormalisationEnabled specifies if the volume should be normalised according
	// to Spotify parameters. Only track normalization is supported.
	NormalisationEnabled bool
	// NormalisationUseAlbumGain specifies whether album gain instead of track gain
	// should be used for normalisation
	NormalisationUseAlbumGain bool
	// NormalisationPregain specifies the pre-gain to apply when normalising the volume
	// in dB. Use negative values to avoid clipping.
	NormalisationPregain float32

	// CrossfadeDuration specifies for how long tracks should overlap during
	// a track change. Zero disables crossfading.
	CrossfadeDuration time.Duration

	// CountryCode reports the country code to use for media restrictions. It is
	// read while building a stream, which happens off the daemon's player loop,
	// so it is a function rather than a pointer the daemon writes through.
	CountryCode func() string

	// AudioBackend specifies the audio backend to use (alsa, pulseaudio, etc).
	AudioBackend string
	// AudioBackendRuntimeSocket specifies a prefixed with protocol (e.g. `unix:` or `tcp:`) path
	// to a runtime socket of audio backend.
	//
	// This feature is support only for the pulseaudio backend.
	AudioBackendRuntimeSocket string
	// AudioBackendCallTimeout bounds how long a single call to the backend's
	// server may take before it's treated as failed. Zero uses the backend's
	// own default.
	//
	// This is only supported on the pulseaudio backend. See
	// output.NewOutputOptions.CallTimeout for why this needs to be tunable.
	AudioBackendCallTimeout time.Duration
	// AudioDevice specifies the audio device name.
	//
	// This feature is support only for the alsa and pulseaudio backend.
	AudioDevice string
	// MixerDevice specifies the audio mixer name.
	//
	// This feature is support only for the alsa backend.
	MixerDevice string
	// MixerControlName specifies the mixer control name.
	//
	// This only works in combination with Mixer.
	MixerControlName string
	// AudioBufferTime is the buffer time in microseconds.
	//
	// This is only supported on the alsa backend.
	AudioBufferTime int
	// AudioPeriodCount is the number of periods to request.
	//
	// This is only supported on the alsa backend.
	AudioPeriodCount int

	// ExternalVolume specifies, if the volume is controlled outside the app.
	//
	// This is only supported on the alsa and pipe backends.
	// The PulseAudio backend always uses external volume.
	ExternalVolume bool

	// VolumeUpdate is a channel on which volume updates will be sent back to
	// Spotify. This must be a buffered channel.
	VolumeUpdate chan float32

	// AudioOutputPipe is the path to the output pipe.
	//
	// This is only supported on the pipe backend.
	AudioOutputPipe string

	// AudioOutputPipeFormat is the format of the output pipe.
	// Available formats are: "s16le", "s32le", "f32le". Default is "s16le".
	//
	// This is only supported on the pipe backend.
	AudioOutputPipeFormat string

	// AudioOutputPipeWaitForReader makes the pipe backend wait for a reader to
	// appear when opening the FIFO, instead of failing if none is present at the
	// time playback starts. This is useful for readers (e.g. snapcast with
	// dryout) that only connect to the FIFO when data is expected.
	//
	// This is only supported on the pipe backend.
	AudioOutputPipeWaitForReader bool

	// OptimisticPlaybackReplies changes when Play/Pause/Seek/Set commands
	// reply relative to the output backend actually confirming the change:
	//
	//   - false (default): waits for the output call (e.g. Resume) to finish
	//     before replying, so the caller - including, for a command that
	//     came from Spotify's dealer, Spotify itself - sees an accurate
	//     result, at the cost of taking as long as the backend does.
	//   - true: replies with success immediately and performs the output
	//     call afterward. A failure is only logged and the output discarded,
	//     to be recreated on the next play/seek attempt - never reported
	//     back to the original caller. This trades reply accuracy for
	//     latency: on a backend whose calls can be slow (see e.g. the
	//     pulseaudio driver's CallTimeout), Spotify's dealer can decide the
	//     device is unresponsive and force a reconnect while we're still
	//     waiting on a slow call - even though playback would have kept
	//     working locally regardless of that connection.
	//
	// Off by default because it makes the reply's success less trustworthy;
	// worth enabling specifically on a setup where a slow backend is causing
	// disconnects.
	OptimisticPlaybackReplies bool
}

func NewPlayer(opts *Options) (*Player, error) {
	p := &Player{
		log:                       opts.Log,
		crossfadeSamples:          int(opts.CrossfadeDuration*SampleRate/time.Second) * Channels,
		sp:                        opts.Spclient,
		audioKey:                  opts.AudioKey,
		events:                    opts.Events,
		cache:                     opts.Cache,
		cdnQuarantine:             make(map[string]time.Time),
		flacEnabled:               opts.FlacEnabled,
		normalisationEnabled:      opts.NormalisationEnabled,
		normalisationUseAlbumGain: opts.NormalisationUseAlbumGain,
		normalisationPregain:      opts.NormalisationPregain,
		countryCode:               opts.CountryCode,
		defaultAudioDevice:        opts.AudioDevice,
		optimisticPlaybackReplies: opts.OptimisticPlaybackReplies,
		newOutput: func(reader librespot.Float32Reader, volume float32, device string) (output.Output, error) {
			return output.NewOutput(&output.NewOutputOptions{
				Log:                     opts.Log,
				Backend:                 opts.AudioBackend,
				Reader:                  reader,
				SampleRate:              SampleRate,
				ChannelCount:            Channels,
				Device:                  device,
				RuntimeSocket:           opts.AudioBackendRuntimeSocket,
				CallTimeout:             opts.AudioBackendCallTimeout,
				Mixer:                   opts.MixerDevice,
				Control:                 opts.MixerControlName,
				InitialVolume:           volume,
				BufferTimeMicro:         opts.AudioBufferTime,
				PeriodCount:             opts.AudioPeriodCount,
				ExternalVolume:          opts.ExternalVolume,
				VolumeUpdate:            opts.VolumeUpdate,
				OutputPipe:              opts.AudioOutputPipe,
				OutputPipeFormat:        opts.AudioOutputPipeFormat,
				OutputPipeWaitForReader: opts.AudioOutputPipeWaitForReader,
			})
		},

		cmd:    make(chan playerCmd),
		ev:     make(chan Event, 128),
		closed: make(chan struct{}),
	}

	go p.manageLoop()

	return p, nil
}

func (p *Player) manageLoop() {
	// currently available output device
	var out output.Output
	outErr := make(<-chan error)

	// closeOutput discards the current output device. Any output method
	// failure - including a bounded-timeout error from a wedged backend, see
	// e.g. the pulseaudio driver - must not be followed by reusing the same
	// device: some backends leave internal state behind that makes a retried
	// call silently no-op instead of actually failing or succeeding.
	closeOutput := func() {
		_ = out.Close()
		out = nil
		outErr = make(<-chan error)
	}

	// initial volume is 1
	volume := float32(1)

	// whether the output is paused, so seek knows whether to resume after Drop
	paused := false

	// current output device; can be changed at runtime via playerCmdReopenOutput
	device := p.defaultAudioDevice

	// init main source
	source := NewSwitchingAudioSource(p.crossfadeSamples)

	// ensureOutput creates a new output device if one isn't already open.
	// Play and Seek only ever reach this loop once the daemon has confirmed a
	// primary stream is set (see AppPlayer.play/seek), so out == nil at that
	// point always means a previous output was discarded after a failure
	// (closeOutput above), never "nothing to play yet" - safe to recreate
	// unconditionally.
	ensureOutput := func() error {
		if out != nil {
			return nil
		}

		var err error
		out, err = p.newOutput(source, volume, device)
		if err != nil {
			return err
		}

		outErr = out.Error()
		p.log.Debugf("created new output device")
		return nil
	}

	// runOutputOp runs op (a possibly slow output call: Resume, Pause) and
	// replies to cmd depending on p.optimisticPlaybackReplies:
	//
	//   - false (default): waits for op to finish, replying with its error.
	//     A failure also discards the output (closeOutput) so a broken
	//     instance isn't reused.
	//   - true: replies with success immediately, then runs op. A failure is
	//     only logged and the output discarded, to be recreated on the next
	//     play/seek attempt (see ensureOutput) - never reported back to the
	//     original caller.
	//
	// onSuccess runs once the reply has been decided either way - e.g. for
	// updating paused/startedPlaying or emitting an Event - before op in the
	// optimistic path, since op hasn't necessarily finished by the time the
	// reply already went out. See Options.OptimisticPlaybackReplies's doc
	// comment for why this trade-off exists.
	runOutputOp := func(cmd playerCmd, op func() error, onSuccess func()) {
		if p.optimisticPlaybackReplies {
			cmd.resp <- nil
			onSuccess()
			if err := op(); err != nil {
				closeOutput()
				p.log.WithError(err).Warnf("output failed after optimistic reply")
			}
			return
		}

		if err := op(); err != nil {
			closeOutput()
			cmd.resp <- err
			return
		}
		cmd.resp <- nil
		onSuccess()
	}

loop:
	for {
		select {
		case cmd := <-p.cmd:
			switch cmd.typ {
			case playerCmdSet:
				data := cmd.data.(playerCmdDataSet)
				if !data.primary {
					source.SetSecondary(data.source)
					cmd.resp <- nil
					break
				}

				if err := ensureOutput(); err != nil {
					cmd.resp <- err
					break
				}

				// Flush the previous source before switching, otherwise the
				// new track's opening is buffered then dropped, clipping it on
				// pulseaudio (#292).
				if data.drop {
					_ = out.Drop()

					// EXPERIMENTAL: same settle delay as the seek path (see
					// its comment for the underlying reasoning) - a flush
					// immediately followed by a restart hangs on at least
					// one real PulseAudio setup, while the same sequence
					// with a gap in between succeeds. This path does the
					// exact same flush-then-restart on a track skip/change.
					time.Sleep(300 * time.Millisecond)
				}

				// Counted before the events below so they carry the stream they
				// describe, and so that whoever set it can tell which that was.
				p.streamGen.Add(1)

				source.SetPrimary(data.source)

				runOutputOp(cmd, func() error {
					if data.paused {
						return out.Pause()
					}
					return out.Resume()
				}, func() {
					paused = data.paused
					p.startedPlaying = time.Now()
					if data.paused {
						p.ev <- Event{Type: EventTypePause, StreamGen: p.streamGen.Load()}
					} else {
						p.ev <- Event{Type: EventTypePlay, StreamGen: p.streamGen.Load()}
					}
				})
			case playerCmdPlay:
				if err := ensureOutput(); err != nil {
					cmd.resp <- err
					break
				}
				runOutputOp(cmd, out.Resume, func() {
					paused = false
					p.ev <- Event{Type: EventTypeResume, StreamGen: p.streamGen.Load()}
				})
			case playerCmdPause:
				if out == nil {
					paused = true
					cmd.resp <- nil
					break
				}
				runOutputOp(cmd, out.Pause, func() {
					paused = true
					p.ev <- Event{Type: EventTypePause, StreamGen: p.streamGen.Load()}
				})
			case playerCmdStop:
				if out != nil {
					closeOutput()

					p.log.Tracef("closed output device because of stop command")
				}

				cmd.resp <- struct{}{}
				p.ev <- Event{Type: EventTypeStop, StreamGen: p.streamGen.Load()}
			case playerCmdSeek:
				// Update the source's position regardless of output state:
				// previously this was skipped whenever out was nil, silently
				// dropping the seek itself rather than just the audio.
				if err := source.SetPositionMs(cmd.data.(int64)); err != nil {
					cmd.resp <- err
					break
				}

				if out != nil {
					if err := out.Drop(); err != nil {
						closeOutput()
						cmd.resp <- err
						break
					}

					// EXPERIMENTAL: give the backend a moment to settle after
					// the flush above before asking it to restart. Observed
					// on at least one PulseAudio setup (Termux/Android, the
					// OpenSL ES sink module): restarting immediately after a
					// flush hangs waiting for the server's start
					// confirmation, while the exact same flush-then-restart
					// sequence with a natural human delay between the two
					// steps (e.g. pause, then play) succeeds. If this turns
					// out not to help, remove it rather than tuning the
					// duration - it's a guess at a server-side timing
					// sensitivity, not a real fix.
					time.Sleep(300 * time.Millisecond)
				}

				// Drop no longer restarts the stream; (re)create the output
				// and resume unless paused. This also covers out having been
				// nil to begin with (e.g. discarded after an earlier
				// failure): SetPositionMs above already updated where
				// playback continues from.
				if paused {
					cmd.resp <- nil
					break
				}

				if err := ensureOutput(); err != nil {
					cmd.resp <- err
					break
				}

				runOutputOp(cmd, out.Resume, func() {})
			case playerCmdPosition:
				pos := source.PositionMs()
				if out != nil {
					delay, err := out.DelayMs()
					if err != nil {
						p.log.WithError(err).Warnf("failed getting output device delay")
						delay = 0
					}

					cmd.resp <- pos - delay
				} else {
					cmd.resp <- pos
				}
			case playerCmdVolume:
				volume = cmd.data.(float32)
				if out != nil {
					out.SetVolume(volume)
				}
			case playerCmdReopenOutput:
				// Reopen the output on a new device without touching the Spotify
				// session, keeping the current source and playback position.
				device = cmd.data.(string)

				if out == nil {
					// Nothing playing: the new device takes effect the next time
					// an output is opened. Callers wanting audio to resume (e.g.
					// recovery after the device died) should issue a play/resume
					// afterwards.
					cmd.resp <- nil
					break
				}

				// Close the old device before opening the new one: some backends
				// (e.g. pulseaudio) start reading from the source as soon as the
				// output is constructed, so two live outputs would corrupt the
				// stream. A sub-second gap from the discarded buffer is expected.
				_ = out.Drop()
				closeOutput()

				newOut, err := p.newOutput(source, volume, device)
				if err != nil {
					// The old device is already gone; playback stays silent until
					// an output is reopened. Surface the failure to the caller.
					p.log.WithError(err).Warnf("failed reopening output on %q", device)
					cmd.resp <- err
					break
				}

				out = newOut
				outErr = out.Error()

				if paused {
					err = out.Pause()
				} else {
					err = out.Resume()
				}
				if err != nil {
					closeOutput()
					cmd.resp <- err
					break
				}

				p.log.Infof("reopened output device on %q", device)
				cmd.resp <- nil
			case playerCmdClose:
				break loop
			default:
				panic("unknown player command")
			}
		case err := <-outErr:
			if err != nil {
				p.log.WithError(err).Errorf("output device failed")
			}

			// the current output device has exited, clean it up
			closeOutput()

			p.log.Tracef("cleared closed output device")

			// FIXME: this is called even if not needed, like when autoplay starts
			p.ev <- Event{Type: EventTypeStop, StreamGen: p.streamGen.Load(), Err: err}
		case <-source.Done():
			p.ev <- Event{Type: EventTypeNotPlaying, StreamGen: p.streamGen.Load()}
		}
	}

	close(p.closed)

	_ = source.Close()

	if out != nil {
		_ = out.Close()
		out = nil
	}
}

func (p *Player) HasBeenPlayingFor() time.Duration {
	if p.startedPlaying.IsZero() {
		return 0
	}

	return time.Since(p.startedPlaying)
}

// StreamGen identifies the primary stream currently set, counting up each time
// one is set. Read it after SetPrimaryStream to learn which generation the
// stream just handed over is; events carry the same value.
func (p *Player) StreamGen() uint64 {
	return p.streamGen.Load()
}

func (p *Player) Receive() <-chan Event {
	return p.ev
}

// send hands cmd to manageLoop, reporting false if the player has already been
// closed and the command was therefore not delivered. Once the send succeeds
// manageLoop always answers cmd.resp before it can exit, so callers may wait on
// the response unconditionally.
func (p *Player) send(cmd playerCmd) bool {
	select {
	case p.cmd <- cmd:
		return true
	case <-p.closed:
		return false
	}
}

// Close stops the player. It is safe to call more than once and safe to call
// while other goroutines are issuing commands: those get ErrPlayerClosed.
func (p *Player) Close() {
	p.send(playerCmd{typ: playerCmdClose})
}

func (p *Player) SetVolume(val uint32) {
	vol := float32(val) / MaxStateVolume
	p.send(playerCmd{typ: playerCmdVolume, data: vol})
}

func (p *Player) Play() error {
	resp := make(chan any, 1)
	if !p.send(playerCmd{typ: playerCmdPlay, resp: resp}) {
		return ErrPlayerClosed
	}
	if err := <-resp; err != nil {
		return err.(error)
	}

	return nil
}

func (p *Player) Pause() error {
	resp := make(chan any, 1)
	if !p.send(playerCmd{typ: playerCmdPause, resp: resp}) {
		return ErrPlayerClosed
	}
	if err := <-resp; err != nil {
		return err.(error)
	}

	return nil
}

func (p *Player) Stop() {
	resp := make(chan any, 1)
	if !p.send(playerCmd{typ: playerCmdStop, resp: resp}) {
		return
	}
	<-resp
}

func (p *Player) SeekMs(pos int64) error {
	resp := make(chan any, 1)
	if !p.send(playerCmd{typ: playerCmdSeek, data: pos, resp: resp}) {
		return ErrPlayerClosed
	}
	if err := <-resp; err != nil {
		return err.(error)
	}

	return nil
}

// PositionMs returns the current playback position, or zero if the player has
// been closed.
func (p *Player) PositionMs() int64 {
	resp := make(chan any, 1)
	if !p.send(playerCmd{typ: playerCmdPosition, resp: resp}) {
		return 0
	}
	pos := <-resp
	return pos.(int64)
}

// ReopenOutput reopens the audio output on the given device without touching
// the Spotify session, preserving the current playback position, paused state
// and volume. If playback is currently active it switches devices live (with a
// brief audio gap); if nothing is playing it just records the device for the
// next output open. It returns an error if the new device fails to open, in
// which case playback is left stopped.
func (p *Player) ReopenOutput(device string) error {
	resp := make(chan any, 1)
	if !p.send(playerCmd{typ: playerCmdReopenOutput, data: device, resp: resp}) {
		return ErrPlayerClosed
	}
	if err := <-resp; err != nil {
		return err.(error)
	}

	return nil
}

func (p *Player) SetPrimaryStream(source librespot.AudioSource, paused, drop bool) error {
	resp := make(chan any)
	if !p.send(playerCmd{typ: playerCmdSet, data: playerCmdDataSet{source: source, primary: true, paused: paused, drop: drop}, resp: resp}) {
		return ErrPlayerClosed
	}
	if err := <-resp; err != nil {
		return err.(error)
	}

	return nil
}

func (p *Player) SetSecondaryStream(source librespot.AudioSource) {
	resp := make(chan any)
	if !p.send(playerCmd{typ: playerCmdSet, data: playerCmdDataSet{source: source, primary: false}, resp: resp}) {
		return
	}
	<-resp
}

func (p *Player) httpChunkedReaderFromStorageResolve(log librespot.Logger, client *http.Client, storageResolve *downloadpb.StorageResolveResponse) (*audio.HttpChunkedReader, error) {
	if storageResolve.Result == downloadpb.StorageResolveResponse_STORAGE {
		return nil, fmt.Errorf("old storage not supported")
	} else if storageResolve.Result == downloadpb.StorageResolveResponse_RESTRICTED {
		return nil, fmt.Errorf("storage is restricted")
	} else if storageResolve.Result == downloadpb.StorageResolveResponse_CDN {
		if len(storageResolve.Cdnurl) == 0 {
			return nil, fmt.Errorf("no cdn urls")
		}

		log.Tracef("found %d cdn urls", len(storageResolve.Cdnurl))

		var err error
		for i := 0; i < len(storageResolve.Cdnurl); i++ {
			var cdnUrl *url.URL
			cdnUrl, err = url.Parse(storageResolve.Cdnurl[i])
			if err != nil {
				log.WithError(err).WithField("url", storageResolve.Cdnurl[i]).Warnf("failed parsing cdn url, trying next url")
				continue
			}

			if lastFailed, found := p.cdnQuarantine[cdnUrl.Host]; found {
				if i == len(storageResolve.Cdnurl)-1 {
					log.WithField("host", cdnUrl.Host).Warnf("cannot skip cdn url because it is the last one")
				} else if time.Since(lastFailed) < CdnUrlQuarantineDuration {
					log.WithField("host", cdnUrl.Host).Infof("skipping cdn url because it has failed recently")
					continue
				}
			}

			var rawStream *audio.HttpChunkedReader
			rawStream, err = audio.NewHttpChunkedReader(log, client, cdnUrl.String())
			if err != nil {
				log.WithError(err).WithField("host", cdnUrl.Host).Warnf("failed creating chunked reader, trying next url")
				p.cdnQuarantine[cdnUrl.Host] = time.Now()
				continue
			}

			delete(p.cdnQuarantine, cdnUrl.Host)
			return rawStream, nil
		}

		return nil, fmt.Errorf("failed creating chunked reader for any cdn url: %w", err)
	} else {
		return nil, fmt.Errorf("unknown storage resolve result: %s", storageResolve.Result)
	}
}

func (p *Player) retrieveAudioKey(ctx context.Context, spotId librespot.SpotifyId, fileId []byte) ([]byte, error) {
	if playplay.Plugin.IsSupported() {
		resp, err := p.sp.PlayPlayRequest(ctx, fileId, &streamingpb.PlayPlayLicenseRequest{
			Version:       ptr(playplay.Plugin.GetVersion()),
			Token:         playplay.Plugin.GetToken(),
			ContentType:   ptr(streamingpb.ContentType_AUDIO_TRACK),
			Interactivity: ptr(streamingpb.Interactivity_INTERACTIVE),
			Timestamp:     ptr(time.Now().Unix()),
		})
		if err != nil {
			return nil, fmt.Errorf("failed requesting playplay license: %w", err)
		}

		key, err := playplay.Plugin.Deobfuscate(resp.ObfuscatedKey, fileId)
		if err != nil {
			return nil, fmt.Errorf("failed deobfuscating playplay key: %w", err)
		}

		return key, nil
	}

	return p.audioKey.Request(ctx, spotId.Id(), fileId)
}

// Spotify normalizes to -14 dB LUFS according to ITU-R BS.1770 standard
// See https://support.spotify.com/us/artists/article/loudness-normalization/
const spotifyLoudnessTarget = -14.0

func calculateNormalisationFactor(params *audiofilespb.NormalizationParams, pregain float32) float32 {
	return normalisationFactorFor(params.LoudnessDb, params.TruePeakDb, pregain)
}

// normalisationFactorFor is the same calculation for audio that carries its
// loudness outside NormalizationParams, as DJ narration does in its
// narration.*.loudness and narration.*.true_peak metadata.
func normalisationFactorFor(loudnessDb, truePeakDb, pregain float32) float32 {
	// LoudnessDb is the integrated loudness of the track in LUFS (ITU-R BS.1770)
	// To normalize, calculate the gain needed to reach Spotify's target of -14 LUFS
	gainDb := spotifyLoudnessTarget - loudnessDb + pregain

	// Convert gain from dB to linear scale
	normalisationFactor := float32(math.Pow(10, float64(gainDb/20)))

	// TruePeakDb from audio files response is in dBTP (dB True Peak)
	truePeakLinear := float32(math.Pow(10, float64(truePeakDb)/20))
	if truePeakLinear <= 0 {
		return normalisationFactor
	}

	// Clamp to avoid exceeding full-scale (0 dBFS) after normalization
	// If the normalized peak would exceed 1.0, reduce the gain
	if normalisationFactor*truePeakLinear > 1 {
		normalisationFactor = 1 / truePeakLinear
	}
	return normalisationFactor
}

func (p *Player) getUnrestrictedTrack(ctx context.Context, spotId librespot.SpotifyId) (*metadatapb.Track, error) {
	var trackMeta metadatapb.Track
	err := p.sp.ExtendedMetadataSimple(ctx, spotId, extmetadatapb.ExtensionKind_TRACK_V4, &trackMeta)
	if err != nil {
		return nil, fmt.Errorf("failed getting track metadata: %w", err)
	}

	media := librespot.NewMediaFromTrack(&trackMeta)
	if !isMediaRestricted(media, p.countryCode()) {
		return &trackMeta, nil
	}

	for _, alt := range trackMeta.Alternative {
		media = librespot.NewMediaFromTrack(alt)
		if !isMediaRestricted(media, p.countryCode()) {
			// Clear alternatives to avoid confusion
			trackMeta.Alternative = nil

			// The alternative track does not have all fields set, copy them over
			// to the original track metadata.
			trackMeta.Gid = alt.Gid
			trackMeta.File = alt.File
			trackMeta.Preview = alt.Preview
			trackMeta.OriginalAudio = alt.OriginalAudio
			return &trackMeta, nil
		}
	}

	// We tried all alternatives, still restricted
	return nil, librespot.ErrMediaRestricted
}

// StartPosition is where media of the given duration should start playing when
// asked to start at position. A position past the end, which a transfer from a
// client with stale playback state can carry, would end the track the moment it
// started and skip straight to the next one, so the track starts over instead.
func StartPosition(position, duration int64) int64 {
	if position <= 0 || position >= duration {
		return 0
	}
	return position
}

func (p *Player) NewStream(ctx context.Context, client *http.Client, spotId librespot.SpotifyId, bitrate int, mediaPosition int64) (*Stream, error) {
	log := p.log.WithField("uri", spotId.Uri())

	// Remember the id the caller asked for: spotId is reassigned below when a
	// restricted track is relinked to an alternative.
	requestedId := spotId

	playbackId := make([]byte, 16)
	_, _ = rand.Read(playbackId)

	p.events.PreStreamLoadNew(playbackId, spotId, mediaPosition)

	var normalisationFactor float32
	var media *librespot.Media
	var file *metadatapb.AudioFile
	if spotId.Type() == librespot.SpotifyIdTypeTrack {
		trackMeta, err := p.getUnrestrictedTrack(ctx, spotId)
		if err != nil {
			return nil, err
		}

		media = librespot.NewMediaFromTrack(trackMeta)
		spotId = media.Id()

		var audioFilesResp audiofilespb.AudioFilesExtensionResponse
		err = p.sp.ExtendedMetadataSimple(ctx, spotId, extmetadatapb.ExtensionKind_AUDIO_FILES, &audioFilesResp)
		if err != nil {
			return nil, fmt.Errorf("failed getting audio files metadata: %w", err)
		}

		var audioFiles []*metadatapb.AudioFile
		for _, f := range audioFilesResp.Files {
			audioFiles = append(audioFiles, f.File)
		}

		file = selectBestMediaFormat(audioFiles, bitrate, p.flacEnabled)
		if file == nil {
			return nil, librespot.ErrNoSupportedFormats
		}

		if p.normalisationEnabled {
			var params *audiofilespb.NormalizationParams
			if p.normalisationUseAlbumGain {
				params = audioFilesResp.DefaultAlbumNormalizationParams
			} else {
				params = audioFilesResp.DefaultFileNormalizationParams
			}

			if params != nil {
				normalisationFactor = calculateNormalisationFactor(params, p.normalisationPregain)
			} else {
				normalisationFactor = 1
			}
		} else {
			normalisationFactor = 1
		}
	} else if spotId.Type() == librespot.SpotifyIdTypeEpisode {
		var episodeMeta metadatapb.Episode
		err := p.sp.ExtendedMetadataSimple(ctx, spotId, extmetadatapb.ExtensionKind_EPISODE_V4, &episodeMeta)
		if err != nil {
			return nil, fmt.Errorf("failed getting episode metadata: %w", err)
		}

		media = librespot.NewMediaFromEpisode(&episodeMeta)
		if isMediaRestricted(media, p.countryCode()) {
			return nil, librespot.ErrMediaRestricted
		}

		file = selectBestMediaFormat(episodeMeta.Audio, bitrate, p.flacEnabled)
		if file == nil {
			return nil, librespot.ErrNoSupportedFormats
		}

		normalisationFactor = 1
	} else {
		return nil, fmt.Errorf("unsupported spotify type: %s", spotId.Type())
	}

	p.events.PostStreamResolveAudioFile(playbackId, int32(bitrate), media, file)

	log.Debugf("selected format %s (%x)", file.Format.String(), file.FileId)

	audioKey, err := p.retrieveAudioKey(ctx, spotId, file.FileId)
	if err != nil {
		return nil, fmt.Errorf("failed retrieving audio key: %w", err)
	}

	p.events.PostStreamRequestAudioKey(playbackId)

	// Prefer a cached copy of the encrypted audio file when available: this
	// avoids resolving storage and downloading from the CDN entirely. The audio
	// key is still required to decrypt it below.
	var rawStream librespot.SizedReadAtSeeker

	// Close the raw stream if stream setup fails before it is handed off to a
	// Stream (e.g. a cached file that fails to decode); this releases the open
	// file handle or cancels the in-flight download.
	streamHandedOff := false
	defer func() {
		if !streamHandedOff {
			if closer, ok := rawStream.(io.Closer); ok && closer != nil {
				_ = closer.Close()
			}
		}
	}()

	if p.cache != nil {
		if cached, ok := p.cache.File(file.FileId); ok {
			log.Debugf("using cached audio file (%d bytes)", cached.Size())
			rawStream = cached
		}
	}

	if rawStream == nil {
		storageResolve, err := p.sp.ResolveStorageInteractive(ctx, file.FileId, file.Format, false)
		if err != nil {
			return nil, fmt.Errorf("failed resolving track storage: %w", err)
		}

		p.events.PostStreamResolveStorage(playbackId)

		httpStream, err := p.httpChunkedReaderFromStorageResolve(log, client, storageResolve)
		if err != nil {
			return nil, fmt.Errorf("failed creating chunked reader: %w", err)
		}

		p.events.PostStreamInitHttpChunkReader(playbackId, httpStream)

		// Persist the encrypted file to the cache once it has been fully
		// downloaded. This is best-effort: caching failures never affect
		// playback.
		if p.cache != nil {
			fileId := file.FileId
			httpStream.OnComplete(func(r io.ReaderAt, size int64) {
				if err := p.cache.SaveFile(fileId, io.NewSectionReader(r, 0, size)); err != nil {
					log.WithError(err).Warnf("failed caching audio file")
				}
			})
		}

		rawStream = httpStream
	}

	decryptedStream, err := audio.NewAesAudioDecryptor(rawStream, audioKey)
	if err != nil {
		return nil, fmt.Errorf("failed intializing audio decryptor: %w", err)
	}

	var stream librespot.AudioSource
	var sampleRate, bitDepth int32

	audioFormat := GetAudioFileFormatAudioFormat(*file.Format)
	if audioFormat == AudioFormatOGGVorbis {
		audioStream, meta, err := vorbis.ExtractMetadataPage(p.log, decryptedStream, rawStream.Size())
		if err != nil {
			return nil, fmt.Errorf("failed reading metadata page: %w", err)
		}

		vorbisStream, err := vorbis.New(log, audioStream, meta, normalisationFactor)
		if err != nil {
			return nil, fmt.Errorf("failed initializing ogg vorbis stream: %w", err)
		}

		if vorbisStream.SampleRate != SampleRate {
			return nil, fmt.Errorf("unsupported sample rate: %d", vorbisStream.SampleRate)
		} else if vorbisStream.Channels != Channels {
			return nil, fmt.Errorf("unsupported channels: %d", vorbisStream.Channels)
		}

		stream = vorbisStream
		sampleRate = vorbisStream.SampleRate
	} else if audioFormat == AudioFormatFLAC {
		audioStream := io.NewSectionReader(decryptedStream, 0, rawStream.Size())
		flacStream, err := flac.New(log, audioStream, normalisationFactor)
		if err != nil {
			return nil, fmt.Errorf("failed initializing flac stream: %w", err)
		}

		if flacStream.SampleRate != SampleRate {
			return nil, fmt.Errorf("unsupported sample rate: %d", flacStream.SampleRate)
		} else if flacStream.Channels != Channels {
			return nil, fmt.Errorf("unsupported channels: %d", flacStream.Channels)
		}

		stream = flacStream
		sampleRate = flacStream.SampleRate
		bitDepth = flacStream.BitDepth
	} else if audioFormat == AudioFormatMP3 {
		audioStream := io.NewSectionReader(decryptedStream, 0, rawStream.Size())
		mp3Stream, err := mp3.New(log, audioStream, normalisationFactor)
		if err != nil {
			return nil, fmt.Errorf("failed initializing mp3 stream: %w", err)
		}

		if mp3Stream.SampleRate != SampleRate {
			return nil, fmt.Errorf("unsupported sample rate: %d", mp3Stream.SampleRate)
		} else if mp3Stream.Channels != Channels {
			return nil, fmt.Errorf("unsupported channels: %d", mp3Stream.Channels)
		}

		stream = mp3Stream
		sampleRate = mp3Stream.SampleRate
	} else {
		return nil, fmt.Errorf("unsupported audio format: %s", *file.Format)
	}

	// Seek to the correct position if needed.
	if position := StartPosition(mediaPosition, int64(media.Duration())); position > 0 {
		if err := stream.SetPositionMs(position); err != nil {
			return nil, fmt.Errorf("failed seeking stream: %w", err)
		}
	} else if mediaPosition > 0 {
		log.Debugf("start position %dms is past the end (%dms), starting from the beginning", mediaPosition, media.Duration())
	}

	streamHandedOff = true
	return &Stream{
		PlaybackId:  playbackId,
		RequestedId: requestedId,
		Source:      stream,
		Media:       media,
		File:        file,
		SampleRate:  sampleRate,
		BitDepth:    bitDepth,
	}, nil
}
